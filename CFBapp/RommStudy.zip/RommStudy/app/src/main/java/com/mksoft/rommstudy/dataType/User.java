package com.mksoft.rommstudy.dataType;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity(tableName = "user")
public class User {
    public User() {
        this.uid = -1;
        this.userName = "";
        this.userMajor = "";
        this.age = -1;
    }


    @PrimaryKey
    public int uid;

    @ColumnInfo(name = "user_name")
    public String userName;

    @ColumnInfo(name = "user_major")
    public String userMajor;

    @ColumnInfo(name = "user_age")
    public int age;



}
