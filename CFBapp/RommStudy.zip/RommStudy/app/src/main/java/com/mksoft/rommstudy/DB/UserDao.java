package com.mksoft.rommstudy.DB;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.mksoft.rommstudy.dataType.User;

import java.util.List;

import static android.arch.persistence.room.OnConflictStrategy.REPLACE;

@Dao
public interface UserDao {

    @Query("SELECT * FROM user")
    List<User> getAll();

    @Query("SELECT * FROM user WHERE user_major IN (:major)")
    List<User> getAllByMajor(String major);

    @Query("SELECT * FROM user WHERE user_name IN(:name)")
    List<User> getAllByName(String name);

    @Query("SELECT * FROM user WHERE user_age IN(:age)")
    List<User> getAllByAge(int age);

    @Insert(onConflict = REPLACE)
    void insertUser(User user);

    @Query("DELETE from user")
    void deleteAll();


}
