package com.mksoft.rommstudy.DB;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.migration.Migration;
import android.content.Context;

import com.mksoft.rommstudy.dataType.User;

import static android.arch.persistence.room.Room.*;

@Database(entities = {User.class}, version = 1)
public abstract class AppDB extends RoomDatabase {
    public abstract UserDao userDao();
    private AppDB appDB;

    public AppDB getInstance(Context context){
        if(appDB != null)
            return appDB;

        return appDB = Room.databaseBuilder(context.getApplicationContext(),
                AppDB.class, "userDB").fallbackToDestructiveMigration().build();
    }
    public void destroyInstance(){
        appDB = null;
    }

}
